# 🐸 Frog Website

Simple static website about frogs.

## Features
- Clean green theme
- Sections: Home, Facts, Gallery

## How to Run
Open `index.html` in your browser.

## Author
Gudhal Production
